<?php 

echo "<script>";
echo "gCodeChanged = true;".$_POST['code']."</script>";


?>